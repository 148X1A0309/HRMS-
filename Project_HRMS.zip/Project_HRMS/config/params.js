module.exports = {
	port: 8010,
	hrms: "mongodb+srv://chanduboddupalli:148X1A0309@cluster0.s6yvc.mongodb.net",
	JWT_SECRET: 'ems_employee_backend_services',
};
